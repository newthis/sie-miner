package ok;


import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import org.eclipse.jdt.core.ICompilationUnit;
import org.eclipse.jdt.core.dom.FieldDeclaration;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import sie.db.entity.CodeComment;
import sie.db.entity.Field;
import sie.db.entity.SType;
import sie.db.entity.SourceContainer;
import sie.parser.java.FieldExtractor;
import sie.parser.java.comments.CommentParser;
import test.sie.utils.ParserBase;

public class FieldExtractorTester {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		for(FieldDeclaration f: ParserBase.getFieldDeclaration())
		 pInstanceVariableNode = f;
		
	ICompilationUnit c = ParserBase.getICompilationUnit();
	cp= new CommentParser(c);
	st.setName("Class1");
	st.setBelongingPackage(new SourceContainer("test"));
	Set<CodeComment> comments= new HashSet<>();
	comments.add(new CodeComment("variabile a"));
	oracolo.setComments(comments);
	oracolo.setName("field");
	oracolo.setOwner(st);
	oracolo.setVisibility("private");
	oracolo.setInitialization("a");
	oracolo.setType(new SType(new SourceContainer("java.lang"),"String"));
	}

	@Before
	public void setUp() throws Exception {
	}

	@Test(expected = IllegalArgumentException.class)
	public void tc_0_01() {
		FieldExtractor.parse(null, cp, st);
	}

	@Test(expected = IllegalArgumentException.class)
	public void tc_0_02() {
		FieldExtractor.parse(pInstanceVariableNode, null, st);
	}

	@Test(expected = IllegalArgumentException.class)
	public void tc_0_03() {
		FieldExtractor.parse(pInstanceVariableNode, cp, null);
	}

	@Test
	public void tc_0_04() {
		Field f = FieldExtractor.parse(pInstanceVariableNode, cp, st);
		assert (f.equals(oracolo));
	}

	private static FieldDeclaration pInstanceVariableNode;
	private static CommentParser cp;
	private static SType st = new SType();

	private static final Field oracolo = new Field();
}