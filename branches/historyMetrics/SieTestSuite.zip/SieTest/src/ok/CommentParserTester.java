package ok;

import static org.junit.Assert.*;

import java.util.HashSet;
import java.util.Set;

import org.eclipse.jdt.core.ICompilationUnit;
import org.eclipse.jdt.core.JavaModelException;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import sie.db.entity.CodeComment;
import sie.parser.java.comments.CommentParser;
import test.sie.utils.ParserBase;

public class CommentParserTester {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		icu = ParserBase.getICompilationUnit();
		CodeComment meth = new CodeComment("/* metodo stampa */");
		CodeComment cls = new CodeComment("/** Classe di prova */");
		CodeComment var = new CodeComment("//variabile a");
		
		oracoloClass.add(cls);
		oracoloClass.add(var);
		oracoloClass.add(meth);
		
		oracoloMethods.add(meth);
		oracoloFields.add(var);
	}

	private static ICompilationUnit icu;

	@Before
	public void setUp() throws Exception {
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void test_1_01() {
		try {
			cp = new CommentParser(null);
		} catch (JavaModelException e) {
			fail(e.getMessage());
		}
	}
	
	@Test
	public void test_1_02() {
		try {
			cp = new CommentParser(icu);
		} catch (JavaModelException e) {
			fail(e.getMessage());
		}
		
		assertEquals(oracoloClass, cp.getClassComments("Class1"));
		assertEquals(oracoloFields, cp.getFieldComments("field"));
		assertEquals(oracoloMethods, cp.getMethodComments("print"));
	}
	
	private CommentParser cp;
	
	private static Set<CodeComment> oracoloFields = new HashSet<>();
	private static Set<CodeComment> oracoloMethods = new HashSet<>();
	private static Set<CodeComment> oracoloClass = new HashSet<>();
}
