package test.sie.parser.java;

import static org.junit.Assert.*;

import org.eclipse.jdt.core.IPackageFragment;
import org.eclipse.jdt.core.JavaModelException;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import sie.db.entity.Project;
import sie.db.entity.SourceContainer;
import sie.parser.java.PackageExtractor;
import test.sie.utils.ParserBase;

public class PackageExtractorTester {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		ipf=ParserBase.getPackageFragment();
		oracolo.setName("namePackage");
		oracolo.setNumLines(30);
		oracolo.setProject(new Project("projName"));
	}

	private static IPackageFragment ipf;
	private static SourceContainer oracolo;

	@Before
	public void setUp() throws Exception {
	}

	@Test(expected = IllegalArgumentException.class)
	public void TC_4_01() {
		try {
			PackageExtractor.parse(null);
		} catch (JavaModelException e) {
			fail(e.getMessage());
		}
	}
	
	@Test
	public void TC_4_02() {
		SourceContainer sc = null;
		try {
			sc = PackageExtractor.parse(ipf);
		} catch (JavaModelException e) {
			fail(e.getMessage());
		}
		
		assertNotNull(sc);
		
		assertEquals(sc, oracolo);
	}

}
