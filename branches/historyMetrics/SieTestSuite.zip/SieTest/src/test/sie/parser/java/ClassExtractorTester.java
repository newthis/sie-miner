package test.sie.parser.java;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import org.eclipse.jdt.core.ICompilationUnit;
import org.eclipse.jdt.core.JavaModelException;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import sie.db.entity.CodeComment;
import sie.db.entity.Field;
import sie.db.entity.Import;
import sie.db.entity.Method;
import sie.db.entity.SType;
import sie.db.entity.SourceContainer;
import sie.parser.java.ClassExtractor;
import test.sie.utils.ParserBase;

public class ClassExtractorTester {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		ICompilationUnit icu = null;
		ib.setName("Test");
		icu = ParserBase.getICompilationUnit();
		SType st = null;
		st = new SType();
		st.setBelongingPackage(new SourceContainer("test"));
		Set<CodeComment> comments = new HashSet<>();
		comments.add(new CodeComment("/** Classe di prova */"));
		comments.add(new CodeComment("variabile a"));
		comments.add(new CodeComment("metodo stampa"));
		st.setComments(comments);
		Set<Import> imp = new HashSet<>();
		imp.add(new SourceContainer("ArrayList"));
		st.setImported(imp);
		SType s= new SType("interface1");
		Set<SType> listClass = new HashSet<>();
		listClass.add(s);
		st.setImplemented(listClass);
		Set<Field> instanceVariables = new HashSet<>();
		instanceVariables.add(new Field("field"));
		st.setInstanceVariables(instanceVariables);
		st.setInterf(false);
		Set<Method> methods= new HashSet<>();
		methods.add(new Method("print"));
		st.setMethods(methods);
		st.setName("Class1");
		st.setNumLinee(11);
		oracolo.add(st);
	}

	private static SourceContainer ib;
	private static ICompilationUnit icu;
	private static ArrayList<SType> oracolo;

	@Before
	public void setUp() throws Exception {
	}

	@Test(expected = IllegalArgumentException.class)
	public void TC_3_01() {
		try {
			ClassExtractor.extractClasses(null, ib);
		} catch (JavaModelException e) {
			fail(e.getMessage());
		}
	}

	@Test(expected = IllegalArgumentException.class)
	public void TC_3_02() {
		try {
			ClassExtractor.extractClasses(icu, null);
		} catch (JavaModelException e) {
			fail(e.getMessage());
		}
	}

	@Test(expected = IllegalArgumentException.class)
	public void TC_3_03() {
		Set<SType> classList = null;
		try {
			classList = ClassExtractor.extractClasses(icu, ib);
		} catch (JavaModelException e) {
			fail(e.getMessage());
		}
		
		//testo se ha trovato le classi
		assertNotNull(classList);
		for(SType t1 : classList) {
			SType t2 = findMatches(t1.getSrcPath());
			//testo se ha trovato la corrispondenza con l'oracolo
			assertNotNull(t2);
			//testo se � effettivamente la stessa classe dell'oracolo
			assertEquals(t1, t2);
		}
	}
	
	private SType findMatches(String id) {
		for(SType st : oracolo){
			if(st.getSrcPath() != null && st.getSrcPath().equals(id))
				return st;
		}
		
		return null;
	}
}