package test.sie.parser.java;

import static org.junit.Assert.*;

import java.util.HashSet;
import java.util.Set;

import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import sie.db.entity.CodeComment;
import sie.db.entity.Method;
import sie.db.entity.MethodParameter;
import sie.db.entity.SType;
import sie.db.entity.Variable;
import sie.parser.java.MethodExtractor;
import sie.parser.java.comments.CommentParser;
import test.sie.utils.ParserBase;

public class MethodParserTester {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		for(MethodDeclaration meth : ParserBase.getMethodDeclaration())
			if(meth.getName().equals("name")){
				pMethodNode=meth;
				break;
			}
		cp = new CommentParser(ParserBase.getICompilationUnit());
		cb.setName("class");
		oracolo.setBelongingClass(new SType("Class1"));
		Set<SType> listCatched = new HashSet<>();
		listCatched.add(new SType("Exception"));
		oracolo.setCatchedException(listCatched);
		Set<SType> throwed = new HashSet<>();
		throwed.add(new SType("Exception"));
		oracolo.setThrowedException(throwed);
		Set<CodeComment> comments = new HashSet<>();
		comments.add(new CodeComment("/* metodo stampa */"));
		oracolo.setComments(comments);
		oracolo.setConstructor(false);
		oracolo.setLinesCount(8);
		Set<Variable> variables = new HashSet<>();
		variables.add(new Variable("a1"));
		oracolo.setLocalVariables(variables);
		Set<Method> methodCalls = new HashSet<>();
		methodCalls.add(new Method("println"));
		oracolo.setMethodCalls(methodCalls);
		oracolo.setName("print");
		Set<MethodParameter> param = new HashSet<>();
		MethodParameter p = new MethodParameter();
		p.setName("s");
		p.setType(new SType("String"));
		param.add(p);
		oracolo.setParameters(param);
		oracolo.setReturnType(new SType("void"));
	}
		
	

	@Before
	public void setUp() throws Exception {
	}

	@Test(expected = IllegalArgumentException.class)
	public void TC_2_01() {
		MethodExtractor.parse(null, cb, cp);
	}

	@Test(expected = IllegalArgumentException.class)
	public void TC_2_02() {
		MethodExtractor.parse(pMethodNode, null, cp);
	}

	@Test(expected = IllegalArgumentException.class)
	public void TC_2_03() {
		MethodExtractor.parse(pMethodNode, cb, null);
	}

	@Test
	public void TC_2_04() {
		Method m = MethodExtractor.parse(pMethodNode, cb, cp);
		assertEquals(m, oracolo);
	}

	private static SType cb;
	private static Method oracolo;
	private static CommentParser cp;
	private static MethodDeclaration pMethodNode;
}
