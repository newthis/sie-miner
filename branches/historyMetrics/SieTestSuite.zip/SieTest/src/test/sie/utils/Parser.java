package test.sie.utils;

import java.util.HashSet;
import java.util.Set;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IWorkspace;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.jdt.core.ICompilationUnit;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.IPackageFragment;
import org.eclipse.jdt.core.IPackageFragmentRoot;
import org.eclipse.jdt.core.JavaCore;
import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTParser;
import org.eclipse.jdt.core.dom.ASTVisitor;
import org.eclipse.jdt.core.dom.CompilationUnit;

import sie.db.entity.Field;
import sie.db.entity.Method;
import sie.db.entity.SType;
import sie.parser.java.comments.CommentParser;

public class Parser {
	public void getParser() throws Exception {
		IWorkspace workspace = ResourcesPlugin.getWorkspace();
		IWorkspaceRoot root = workspace.getRoot();
		// Get all projects in the workspace
		IProject project = root.getProject("Test");
		project.open(null);
		// Loop over all projects
		IJavaProject javaProject = JavaCore.create(project);
		javaProject.open(new NullProgressMonitor());
		// Raccoglie tutti i pacchetti del sistema
		for (IPackageFragment ipf : javaProject.getPackageFragments()) {
			// Filtra tutti i pacchetti che non sono stati definiti dall'utente
			if (ipf.getKind() == IPackageFragmentRoot.K_SOURCE
					&& ipf.containsJavaResources()
					&& ipf.getCorrespondingResource() != null) {
				for(ICompilationUnit icu : ipf.getCompilationUnits()) {
					CompilationUnit cu = parse(icu);
					cu.accept(new ASTVisitor() {
						
					});
				}
			}
		}
	}

	private CompilationUnit parse(ICompilationUnit unit) {
		ASTParser parser = ASTParser.newParser(AST.JLS4);
		parser.setKind(ASTParser.K_COMPILATION_UNIT);
		parser.setSource(unit);
		parser.setResolveBindings(true);
		return (CompilationUnit) parser.createAST(null); // parse
	}
	
	private Field[] f;
	private Method[] m;
	private SType[] s;
	private CommentParser cp;
}