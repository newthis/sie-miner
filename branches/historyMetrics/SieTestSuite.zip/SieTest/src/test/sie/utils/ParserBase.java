package test.sie.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Set;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IWorkspace;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.jdt.core.ICompilationUnit;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.IPackageFragment;
import org.eclipse.jdt.core.IPackageFragmentRoot;
import org.eclipse.jdt.core.JavaCore;
import org.eclipse.jdt.core.JavaModelException;
import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTParser;
import org.eclipse.jdt.core.dom.ASTVisitor;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.FieldDeclaration;
import org.eclipse.jdt.core.dom.MethodDeclaration;

public class ParserBase {
	private static CompilationUnit parse(ICompilationUnit icu) {
		ASTParser parser = ASTParser.newParser(AST.JLS4);
		parser.setKind(ASTParser.K_COMPILATION_UNIT);
		parser.setSource(icu);
		parser.setResolveBindings(true);
		return (CompilationUnit) parser.createAST(null); // parse
	}

	public static ICompilationUnit getICompilationUnit()
			throws JavaModelException {
		ICompilationUnit icu = null;
		IWorkspace workspace = ResourcesPlugin.getWorkspace();
		IWorkspaceRoot root = workspace.getRoot();
		// Get all projects in the workspace
		IProject project = root.getProject("Test");
		// Loop over all projects

		IJavaProject p = JavaCore.create(project);
		for (IPackageFragment mypackage : p.getPackageFragments()) {
			if (mypackage.getKind() == IPackageFragmentRoot.K_SOURCE)
				for (ICompilationUnit unit : mypackage.getCompilationUnits())
					icu = unit;
		}
		return icu;
	}

	public static IPackageFragment getPackageFragment()
			throws JavaModelException {
		IPackageFragment ipf = null;
		IWorkspace workspace = ResourcesPlugin.getWorkspace();
		IWorkspaceRoot root = workspace.getRoot();
		// Get all projects in the workspace
		IProject project = root.getProject("Test");
		// Loop over all projects

		IJavaProject p = JavaCore.create(project);
		for (IPackageFragment mypackage : p.getPackageFragments())
			ipf = mypackage;

		return ipf;
	}

	public static Collection<FieldDeclaration> getFieldDeclaration() {
		final Collection<FieldDeclaration> ret = new ArrayList<>();
		CompilationUnit icu = null;
		try {
			icu = parse(getICompilationUnit());
		} catch (JavaModelException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		icu.accept(new ASTVisitor() {

			@Override
			public boolean visit(FieldDeclaration node) {
				ret.add(node);
				return super.visit(node);
			}
		});
		return ret;
	}

	public static Collection<MethodDeclaration> getMethodDeclaration()
			throws JavaModelException {
		final Collection<MethodDeclaration> methodNodes = new ArrayList<>();
		CompilationUnit icu = parse(getICompilationUnit());
		icu.accept(new ASTVisitor() {

			public boolean visit(MethodDeclaration pMethodNode) {
				methodNodes.add(pMethodNode);
				return super.visit(pMethodNode);
			}

		});
		return methodNodes;
	}

	public static <T> boolean checkSetEquals(Set<T> set1, Set<T> set2) {
		for (T t1 : set1)
			if (!set2.contains(t1))
				return false;
		for (T t2 : set2)
			if (!set1.contains(t2))
				return false;
		return true;
	}
}